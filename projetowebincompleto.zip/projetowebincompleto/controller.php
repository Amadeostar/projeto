<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filmes.Net</title>
    <link rel="stylesheet" href="cssprojetoweb.css">
</head>
<body>
        <div class="topnav">
            <a class="active" href="LoginWeb.html">Fazer login</a>
            <a href="LoginWeb.html">Sobre nos</a>
            <a href="LoginWeb.html">Home</a>
         </div>
</body>
</html>
