<?php
session_start();

include("conexao.php");

$nome = mysqli_real_escape_string($conexao, $_POST['nome']);
$usuario = mysqli_real_escape_string($conexao, $_POST['email']);
$senha mysqli_real_escape_string($conexao, $_POST['senha']);
?>