
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vamos fazer o seu cadastro</title>
    <link rel="stylesheet" href="TelaLogin.css">
</head>
<body>
    <div class="login-card">
        <h2>cadastro</h2>
        <h3>Crie o seu Usuario e Senha que você quer cadastrar</h3>
        <form method="POST" class="login-form">
            <input type="text" name="nome" placeholder="Nome" required="required"/>
            <input type="email" name="email" placeholder="Email" required="required"/>
            <input type="passaword" name="senha" placeholder="Senha" required="required"/>
            <button name="cadastro">cadastrar</button>
        </form>
    </div>
    
</body>
</html>

<?php
$usuario = 'root';
$senha = '';
$database = 'login';
$host = 'localhost';

$con = mysqli_connect($host, $usuario, $senha, $database) or die("Error");

if(isset($_POST['nome'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $query = mysqli_query($con, "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')");
   
}

?>