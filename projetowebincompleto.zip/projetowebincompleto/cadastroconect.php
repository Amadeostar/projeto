<?php
$usuario = 'root';
$senha = '';
$database = 'login';
$host = 'localhost';

$con = mysqli_connect($host, $usuario, $senha, $database) or die("Error");

?>