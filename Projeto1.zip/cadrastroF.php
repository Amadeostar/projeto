<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filmes.Net</title>
    <link rel="stylesheet" href="cssprojetoweb.css">
    <link rel="stylesheet" href="CssBotão.css">
</head>
<body>
</br>
    </br>
        </br>
            </br>
                </br>
    <p>O seu cadastro foi realizado com sucesso, clique no botão a baixo para voltar a tela de login</p>
    <div class="botao">
        <a href="LoginWeb.html"><button>Voltar para o login</button></a>
    </div>
</body>
</html>
