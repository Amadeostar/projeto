<?php
include('conexao.php');
if(isset($_POST['email']) || isset($_POST['senha'])){
   if(strlen($_POST['email']) == 0){
    echo "preencha seu email";
   }else if(strlen($_POST['senha']) == 0){
    echo "preencha sua senha";
   }
   else{
    $email = $mysqli->real_escape_string($_POST['email']);
    $senha = $mysqli->real_escape_string($_POST['senha']);

    $sql_code = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha'";
    $sql_query = $mysqli->query($sql_code) or die("Falha na execução do codigo sql: " . $mysqli->error);

    $quantidade = $sql_query->num_rows;
    
    if($quantidade == 1){
           $usuario = $sql_query->fetch_assoc();
           
           if(!isset($_SESSION)){
            session_start();
           }
           $_SESSION['id'] = $usuario['id'];
           $_SESSION['nome'] = $usuario['nome'];

           header("Location: controller.php");
    }
    else{
        echo "falha ao logar! E-mail ou senha incorretos";
    }
   }
   

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login para a aba de Filmes</title>
    <link rel="stylesheet" href="TelaLogin.css">
</head>
<body>
    <div class="login-card">
        <h2>Login</h2>
        <h3>Digite o seu Usuario e Senha</h3>
        <form method="POST" class="login-form">
            <input type="email" name="email" placeholder="Usuario" required="required"/>
            <input type="password" name="senha" placeholder="Senha" required="required"/>
            <a href="cadastro.html">Fazer o seu cadastro</a>
            <button>Login</button>
        </form>
    </div>
    
</body>
</html>